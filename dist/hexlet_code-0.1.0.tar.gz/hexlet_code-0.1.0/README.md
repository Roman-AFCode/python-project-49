### Hexlet tests and linter status:
[![Actions Status](https://github.com/Roman-AFCode/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Roman-AFCode/python-project-49/actions)

### Maintainability Badge:
<a href="https://codeclimate.com/github/Roman-AFCode/python-project-49/maintainability"><img
src="https://api.codeclimate.com/v1/badges/05d8e8d17fd939dcb151/maintainability"
/></a>
---
# Проект игры разума
Вам предстоит пройти испытания на знания математики.
Вас ждут 5 увлекательных игр.
- Проверка чётности
- Калькулятор
- Наибольший общий делитель (НОД)
- Арифметическая прогрессия
- Простое ли число?

Пройдите все игры и получите приз!
- плюс в карму =)


---
### Запись аскинемы
### Игра проверка чётности
https://asciinema.org/a/p7dGZKvJVWR4qNYkbL8Aoror5
### Игра калькулятор
https://asciinema.org/a/2FaPsJfoCQ9zZoQHDYHo3P5O3
### Игра наибольший общий делитель (НОД)
https://asciinema.org/a/qhlkoEkXRoNFQWx7bFpueKimy
### Игра арифметическая прогрессия
https://asciinema.org/a/yzIAodyKMecbyJv95k4O3mxGs
### Игра простое ли число?
https://asciinema.org/a/0X5vg83YE8qkvqn8R1anKwyhb
