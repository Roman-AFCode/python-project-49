### Hexlet tests and linter status:
[![Actions Status](https://github.com/Roman-AFCode/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Roman-AFCode/python-project-49/actions)

### Maintainability Badge:
<a href="https://codeclimate.com/github/Roman-AFCode/python-project-49/maintainability"><img
src="https://api.codeclimate.com/v1/badges/05d8e8d17fd939dcb151/maintainability"
/></a>

### Запись аскинемы
### Игра проверка чётности
https://asciinema.org/a/p7dGZKvJVWR4qNYkbL8Aoror5
