# движок запускающий и проверяющий игры

from brain_games.games.brain_even import parity_check
from brain_games.games.brain_calc import
import prompt


def welcome_user():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')
    return name


def main():
    welcome_user()
    parity_check()


if __name__ == '__main__':
    main()
