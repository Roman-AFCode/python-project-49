from brain_games.games_engine import welcome_user
from brain_games.games.brain_parity import parity_check


def main():
    welcome_user()
    parity_check()


if __name__ == '__main__':
    main()
