# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'You will have to pass the test of knowledge of mathematics. Five exciting games await you.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Roman-AFCode/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Roman-AFCode/python-project-49/actions)\n\n### Maintainability Badge:\n<a href="https://codeclimate.com/github/Roman-AFCode/python-project-49/maintainability"><img\nsrc="https://api.codeclimate.com/v1/badges/05d8e8d17fd939dcb151/maintainability"\n/></a>\n---\n# Проект игры разума\nВам предстоит пройти испытания на знания математики.\nВас ждут 5 увлекательных игр.\n- Проверка чётности\n- Калькулятор\n- Наибольший общий делитель (НОД)\n- Арифметическая прогрессия\n- Простое ли число?\n\nПройдите все игры и получите приз!\n- плюс в карму =)\n\n\n---\n### Запись аскинемы\n### Игра проверка чётности\nhttps://asciinema.org/a/p7dGZKvJVWR4qNYkbL8Aoror5\n### Игра калькулятор\nhttps://asciinema.org/a/2FaPsJfoCQ9zZoQHDYHo3P5O3\n### Игра наибольший общий делитель (НОД)\nhttps://asciinema.org/a/qhlkoEkXRoNFQWx7bFpueKimy\n### Игра арифметическая прогрессия\nhttps://asciinema.org/a/yzIAodyKMecbyJv95k4O3mxGs\n### Игра простое ли число?\nhttps://asciinema.org/a/0X5vg83YE8qkvqn8R1anKwyhb\n',
    'author': 'Roman Ko',
    'author_email': 'roman_ko@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/Roman-AFCode/python-project-49.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
